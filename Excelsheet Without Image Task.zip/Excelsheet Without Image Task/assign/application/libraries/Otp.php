<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');

class Otp {
	
    private static $baseUrl = "http://api.msg91.com/api";
    private static $authKey = "153043A4FZ9DMq591ed45b";
	
	public static function generateOTP($params) {
		$params['authkey'] = Otp::$authKey;
		$params['otp_length'] = 4;
		$params['otp_expiry'] = 5;
		$url = Otp::$baseUrl . '/sendotp.php';
        $postData = '';
		foreach($params as $k => $v) { 
			$postData .= $k . '='.$v.'&'; 
		}
		$postData = rtrim($postData, '&');
		$ch = curl_init();  
		curl_setopt($ch,CURLOPT_URL,$url);
		curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
		curl_setopt($ch,CURLOPT_HEADER, false); 
		curl_setopt($ch, CURLOPT_POST, count($postData));
		curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);    
		$result = curl_exec($ch);
		curl_close($ch);
		$response = json_decode($result,true);
		if($response["type"] == "success") {
			return true;
		}
        return false;
    }
    
    public static function verifyOtp($params) {
		$url = Otp::$baseUrl . '/verifyRequestOTP.php';
		$params['authkey'] = Otp::$authKey;
        $postData = '';
		foreach($params as $k => $v) { 
			$postData .= $k . '='.$v.'&'; 
		}
		$postData = rtrim($postData, '&');
		$ch = curl_init();  
		curl_setopt($ch,CURLOPT_URL,$url);
		curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
		curl_setopt($ch,CURLOPT_HEADER, false); 
		curl_setopt($ch, CURLOPT_POST, count($postData));
		curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);    
		$result = curl_exec($ch);
		curl_close($ch);
		$response = json_decode($result,true);
		if($response["type"] == "success") {
			return true;
		}
        return false;
    }
    
    public static function sendSMS($postData) {
		$url = "http://api.msg91.com/api/sendhttp.php";
		$postData['authkey'] = Otp::$authKey;
        $postData['sender'] = 'BossDK';
        $postData['route'] = 4;
		$ch = curl_init();
		curl_setopt_array($ch, array(
			CURLOPT_URL => $url,
			CURLOPT_RETURNTRANSFER => true,
			CURLOPT_POST => true,
			CURLOPT_POSTFIELDS => $postData
		));
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
		$result = curl_exec($ch);
		if(curl_errno($ch)) {
			return false;
		}
		curl_close($ch);
		return true;
    }
}
