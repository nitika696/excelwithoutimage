<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');

class Image {
	
	public static function displayImage($image_name,$height,$width) {
		$ci = &get_instance();
		$image_path = "uploads/" . $image_name;
		$pathinfo = pathinfo($image_path);
		$image_thumb = "uploads/cache/" . $pathinfo["filename"] . "-" . $height . "-" . $width . "." . $pathinfo["extension"];
		if(!file_exists($image_thumb)) {
			$ci->load->library('image_lib');
			$config['image_library']    = 'gd2';
			$config['source_image']     = $image_path;
			$config['new_image']        = $image_thumb;
			$config['maintain_ratio']   = FALSE;
			$config['height']           = $height;
			$config['width']            = $width;
			$ci->image_lib->initialize($config);
			$ci->image_lib->resize();
			$ci->image_lib->clear();
		}
		return base_url($image_thumb);
	}
	
	public static function displayThumb($image_name) {
		return Image::displayImage($image_name,41,41);
	}
	
	public static function displayLarge($image_name) {
		return Image::displayImage($image_name,350,350);
	}
	
	public static function displayOriginal($image_name) {
		return base_url($baseDestinationUrl.$image_name);
	}
	
	public static function uploadFile($files) {
		$_FILES['image']['name'] = $files['image']['name'];
		$_FILES['image']['type'] = $files['image']['type'];
		$_FILES['image']['tmp_name'] = $files['image']['tmp_name'];
		$_FILES['image']['error'] = $files['image']['error'];
		$_FILES['image']['size'] = $files['image']['size'];
		$ci = &get_instance();
		$config['upload_path'] = './uploads';
		$config['allowed_types'] = '*';
		$config['remove_spaces'] = true;
		$config['overwrite'] = false;
		$config['file_ext_tolower'] = true;
		$config['max_filename'] = 20;
		$config['file_name'] = preg_replace('/[^A-Za-z0-9\-.]/', '',$_FILES['image']['name']);
		$ci->load->library('upload');
		$ci->upload->initialize($config);
		if(!$ci->upload->do_upload('image')) {
			return false;
		}
		return $ci->upload->data('file_name');
	}
}
