 <!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>404 Page Not Found</title>
<style>
p,ul{margin:1em 0}::-moz-selection{background:#b3d4fc;text-shadow:none}::selection{background:#b3d4fc;text-shadow:none}html{padding:30px 10px;font-size:20px;line-height:1.4;color:#737373;background:#f0f0f0;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%}html,input{font-family:"Helvetica Neue",Helvetica,Arial,sans-serif}body{margin:0;padding:0;font-family:font-family: "Helvetica Neue",Helvetica,Arial,sans-serif}h1{margin:0 10px;font-size:36px;text-align:center;line-height:35px}h1 span{color:#bbb}h3{margin:1.5em 0 .5em}ul{padding:0 0 0 40px}.main-container{float:left;width:100%}.top-container{border:1px solid #b3b3b3;border-radius:4px;margin:0 auto;box-shadow:0 1px 10px #a7a7a7,inset 0 1px 0 #fff;background:#fcfcfc;max-width:500px;padding:30px 20px 50px}.container{max-width:380px;width:100%;margin:0 auto}
</style>
</head>
<body>
	<div class="main-container">
		<div class="top-container">
			<div class="container">
				<h1>404 Page Not Found!</h1>
				<p>Sorry, but the page you are looking for not found on this server.</p>
			</div>
		</div>
	</div>
</body>
</html> 
