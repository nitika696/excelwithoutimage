<?php if($this->session->flashdata('error')): ?>
	<div class="form-group m-b-20 session-alert">
		<div class="alert alert-icon alert-danger alert-dismissible fade in" role="alert">
			<button type="button" class="close" data-dismiss="alert" aria-label="Close">
				<span aria-hidden="true">×</span>
			</button>
			<i class="mdi mdi-block-helper"></i>
			<strong>Error!</strong>
			<?php
				echo $this->session->flashdata('error'); 
				$this->session->unset_userdata('error');
			?>
		</div>
	</div>
<?php endif; ?>
<?php if($this->session->flashdata('success')):?>
	<div class="alert alert-icon alert-white alert-success alert-dismissible fade in session-alert" role="alert">
		<button type="button" class="close" data-dismiss="alert" aria-label="Close">
			<span aria-hidden="true">×</span>
		</button>
		<i class="mdi mdi-check-all"></i>
		<strong>Success!</strong>
		<?php 
			echo $this->session->flashdata('success');
			$this->session->unset_userdata('error');
		 ?>
	</div>
<?php endif; ?>
