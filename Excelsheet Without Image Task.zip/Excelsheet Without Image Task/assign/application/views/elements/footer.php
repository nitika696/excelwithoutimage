<div class="footer">
	<div>
		<strong>Company Name</strong> - Copyright &copy; 2018
	</div>
</div>
