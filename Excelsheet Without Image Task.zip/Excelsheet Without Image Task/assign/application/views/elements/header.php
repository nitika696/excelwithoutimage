<div class="topbar">
	<div class="topbar-left">
		<div class="">
			<a href="<?=base_url('enquiry');?>" class="logo">
				<img src="<?=base_url('assets/images/nlogo.png');?>" alt="logo" class="logo-lg" />
				<img src="<?=base_url('assets/images/nlogo.png');?>" alt="logo" class="logo-sm hidden" />
			</a>
		</div>
	</div>
	<div class="navbar navbar-default" role="navigation">
		<div class="container">
			<div class="">
				<div class="pull-left">
					<button type="button" class="button-menu-mobile visible-xs visible-sm">
						<i class="fa fa-bars"></i>
					</button>
					<span class="clearfix"></span>
				</div>
			</div>
		</div>
	</div>
</div>
