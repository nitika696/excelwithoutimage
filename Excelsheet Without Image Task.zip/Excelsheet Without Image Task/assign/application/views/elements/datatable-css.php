<link href="<?=base_url('assets/plugins/datatables/jquery.dataTables.min.css');?>" rel="stylesheet">
<link href="<?=base_url('assets/plugins/datatables/responsive.bootstrap.min.css');?>" rel="stylesheet">
<link href="<?=base_url('assets/plugins/switchery/switchery.min.css');?>" rel="stylesheet">
