<?php $action = $this->router->fetch_method(); $class = $this->router->fetch_class();?>
<aside class="sidebar-navigation">
	<div class="scrollbar-wrapper">
		<div>
			<button type="button" class="button-menu-mobile btn-mobile-view visible-xs visible-sm">
				<i class="mdi mdi-close"></i>
			</button>
			<div class="user-details">
				<div class="pull-left">
					<div class="user-img"><?=strtoupper($this->session->userdata('userName')[0]);?></div>
				</div>
				<div class="user-info">
					<p>Welcome,</p>
					<b><?=$this->session->userdata('userName');?></b>
				</div>
			</div>
            
            
			<ul class="metisMenu nav" id="side-menu">
				
                
				<li class="<?=($class == 'profile' && $action=='index')?'active':'';?>"><a href="javascript: void(0);" aria-expanded="true"><i class="ti-user"></i>Profile <span class="fa arrow"></span></a>
					<ul class="nav-second-level nav" aria-expanded="true">
						<li class="<?=($class == 'profile' && $action=='index')?'active':'';?>"><a href="<?=base_url('profile');?>"> Personal Info</a></li>
						<li><a href="<?=base_url('profile/logout');?>"> Logout</a></li>
					</ul>
				</li>  <!-- 1st li Profile -->
				<?php
				$d = $this->session->userdata('userType');
                 // condition for user and admin.....
                    if($d == "1"){ ?>                
                <li class="<?=($class == 'quicklinks' && $action=='index')?'active':'';?>"><a href="javascript: void(0);" aria-expanded="true"><i class="ti-user"></i>News links <span class="fa arrow"></span></a>
					<ul class="nav-second-level nav" aria-expanded="true">
						 <li class="<?=($class == 'quicklinks' && $action=='index')?'active':'';?>"><a href="<?=base_url('news');?>">Add News</a></li>
						<!--  <li class="<?=($class == 'news' && $action=='index')?'active':'';?>"><a href="<?=base_url('quicklinks/viewnews');?>">View News</a></li> -->
					</ul>
				</li>  <!-- 2nd li quick links -->
				<?php } ?>
				
                
                <li class="<?=($class == 'enquiry' && $action=='index')?'active':'';?>"><a href="<?=base_url('enquiry');?>"><i class="ti-user"></i>Careers</a></li>
                <!-- 3rd li-->
                 <li class="<?=($class == 'contactus' && $action=='index')?'active':'';?>"><a href="<?=base_url('contactus');?>"><i class="ti-user"></i>Contact Us</a></li>
                <!-- 4th li -->                
			</ul>
		</div>
	</div>
</aside>
