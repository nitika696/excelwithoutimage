<script src="<?=base_url('assets/plugins/datatables/jquery.dataTables.min.js');?>"></script>
<script src="<?=base_url('assets/plugins/datatables/dataTables.bootstrap.js');?>"></script>
<script src="<?=base_url('assets/plugins/datatables/dataTables.responsive.min.js');?>"></script>
<script src="<?=base_url('assets/plugins/switchery/switchery.min.js');?>"></script>
