<body>
	<div class="main-container">
		<div class="top-container">
			<div class="container">

<form action="<?php echo base_url();?>question/uploadData" method="post" enctype="multipart/form-data">
    <h4>Upload Excel Sheet Here : </h4>
    <input type="file" name="uploadFile" value="" /><br>
    <input type="submit" name="submit" value="Upload" />
</form>
			</div>
		</div>
	</div>
</body>


 