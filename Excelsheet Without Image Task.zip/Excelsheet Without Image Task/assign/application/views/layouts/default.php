<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8"/>
	<title><?=(!empty($pageTitle))?$pageTitle:CONF_WEBSITE_NAME;?></title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<link rel="shortcut icon" href="<?=base_url('assets/images/favicon.ico');?>">
	<script type="text/javascript">var base_url = '<?php echo base_url(); ?>';</script>
	<link href="<?=base_url('assets/css/bootstrap.min.css');?>" rel="stylesheet">
	<link href="<?=base_url('assets/css/metisMenu.min.css');?>" rel="stylesheet">
	<link href="<?=base_url('assets/css/icons.css');?>" rel="stylesheet">
	<link href="<?=base_url('assets/css/style.css');?>" rel="stylesheet">
	<?php
		if(!empty($pageCss)){
			$this->load->view($pageCss); 
		}
	?>
</head>
<body>
	<div id="page-wrapper">
		<div class="page-contentbar">
				<br/>
				<?php
					if(!empty($pagePath) && $pagePath!=""){
						$this->load->view($pagePath); 
					}
				?>
			<br/>
			<br/>
		</div>
	</div>
	<script src="<?=base_url('assets/js/jquery-2.1.4.min.js');?>"></script>
	<script src="<?=base_url('assets/js/bootstrap.min.js');?>"></script>
	<script src="<?=base_url('assets/js/metisMenu.min.js');?>"></script>
	<script src="<?=base_url('assets/js/jquery.slimscroll.min.js');?>"></script>
	<?php
		if(!empty($pageJs)){
			$this->load->view($pageJs); 
		}
	?>
	<script src="<?=base_url('assets/js/jquery.app.js?t='.time());?>"></script>
	<script>$(document).ready(function(){setTimeout(function(){ $('.session-alert').remove(); }, 8000);});</script>
</body>
</html>
