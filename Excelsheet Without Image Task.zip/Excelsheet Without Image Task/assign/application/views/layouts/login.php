<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8"/>
	<title><?=(!empty($pageTitle))?$pageTitle:CONF_WEBSITE_NAME;?></title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<link rel="shortcut icon" href="<?=base_url('assets/images/favicon.ico');?>">
	<script type="text/javascript">var base_url = '<?php echo base_url(); ?>';</script>
	<link href="<?=base_url('assets/css/bootstrap.min.css');?>" rel="stylesheet">
	<link href="<?=base_url('assets/css/icons.css');?>" rel="stylesheet">
	<link href="<?=base_url('assets/css/style.css');?>" rel="stylesheet">
	<script src="<?=base_url('assets/js/jquery-2.1.4.min.js');?>"></script>
	<script src="<?=base_url('assets/js/bootstrap.min.js');?>"></script>
	<script>$(document).ready(function(){setTimeout(function(){ $('.session-alert').remove(); }, 8000);});</script>
</head>
<body>
	<?php 
		if(!empty($pagePath) && $pagePath!=""){
			$this->load->view($pagePath); 
		}
	?>
</body>
</html>
