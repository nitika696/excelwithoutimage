<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');
 
class Question_model extends CI_Model {
 
    public function importData($data) {
 
        $res = $this->db->insert_batch('tbl_ques',$data);
        if($res){
            return TRUE;
        }else{
            return FALSE;
        }
 
    }
 
}
 
?>