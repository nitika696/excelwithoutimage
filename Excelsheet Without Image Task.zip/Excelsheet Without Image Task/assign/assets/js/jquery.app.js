(function ($) {

    'use strict';

    function initSlimscroll() {
        $('.slimscroll').slimscroll({
            height: 'auto',
            position: 'right',
            size: "5px",
            color: '#9ea5ab'
        });
    }

    function initMetisMenu() {
        $("#side-menu").metisMenu();
    }

    function initLeftMenuCollapse() {
        $('.button-menu-mobile').on('click', function (event) {
            event.preventDefault();
            $("body").toggleClass("nav-collapse");
        });
    }

    function initComponents() {
        $('[data-toggle="tooltip"]').tooltip();
        $('[data-toggle="popover"]').popover();
        $('[data-plugin="switchery"]').each(function (idx, obj) {
            new Switchery($(this)[0], $(this).data());
        });
    }

	function initDependencies() {
		$('body').on('change','.user-status',function(){
			updateStatus($(this).attr('uid'),this.checked,1);
		});
		
		$('body').on('change','.nomination-status',function(){
			updateStatus($(this).attr('pid'),this.checked,2);	
		});
		
		$('body').on('change','.marquee-status',function(){
			updateStatus($(this).attr('mid'),this.checked,3);	
		});
		
		if($("#notify-type").length > 0) {
			$("#notify-type").change(function(){
				var type = $("#notify-type option:selected" ).val();
				if(type=='single') {
					$("#mobile-div").show();
				} else {
					$("#mobile-div").hide();
				}
			});   
		}
		
		if($("#user_dob").length > 0) {
			$('#user_dob').datepicker({
				autoclose: true,
				format: "dd-mm-yyyy",
				endDate: '-0m'
			});
		}
	}
	
	function updateStatus(id,state,type) {
		$.ajax({
			url: base_url + 'users/update',
			type: 'post',
			data: {'id':id,'state':state,'type':type},
			success: function(response) 
			{
				if(response !=1){
					alert(response);
				}
			},
			error: function () {
				alert('Something went wrong!');
			}
		});		
	}
	
	function handleUserTable() 
	{
		console.log('nakulan Test..');
		"use strict";		
		
		// Careers
		if($("#enquiry").length != 0) 
		{
			var oTable = $("#enquiry").DataTable({
				"processing": true,
				"serverSide": true,
				"ajax": {
					"url": base_url+'enquiry/listing',
					"type": "POST"
				},
				"columnDefs": [{ orderable: false, targets: [0] }],
				"order": [[6, "desc" ]]
			});
			
			$('#enquiry').on( 'draw.dt', function () {
				$('[data-plugin="switchery"]').each(function (idx, obj) {
					new Switchery($(this)[0], $(this).data());
				});
			});
			
			$('body').on('click','.del',function() {
				if(confirm('Are you sure?')){
					var elm = $(this);
					var id = elm.attr('ref');
					$.ajax({
						url: base_url+'enquiry/delete',
						type: 'POST',
						data: {'id':id},
						success: function(res){
							oTable.row(elm.parents('tr')).remove().draw();
						},
						error: function () {
							alert('Something went wrong!');
						}
					});
				}
			});
		}
		
		
		// Contact Us
		if($("#contactus").length != 0) {
			var oTable = $("#contactus").DataTable({
				"processing": true,
				"serverSide": true,
				"ajax": {
					"url": base_url+'contactus/listing',
					"type": "POST"
				},
				"columnDefs": [{ orderable: false, targets: [0] }],
				"order": [[6, "desc" ]]
			});
			
			$('#contactus').on( 'draw.dt', function () {
				$('[data-plugin="switchery"]').each(function (idx, obj) {
					new Switchery($(this)[0], $(this).data());
				});
			});
			
			$('body').on('click','.del',function() {
				if(confirm('Are you sure?')){
					var elm = $(this);
					var id = elm.attr('ref');
					console.log(id);
					$.ajax({
						url: base_url+'contactus/delete',
						type: 'POST',
						data: {'id':id},
						success: function(res)
						{
							oTable.row(elm.parents('tr')).remove().draw();
						},
						error: function () 
						{
							alert('Something went wrong!');
						}
					});
				}
			});	
			
		}
		
	
        
        // News
		if($("#news").length != 0) 
		{
			var oTable = $("#news").DataTable({
				"processing": true,
				"serverSide": true,
				"ajax": {
					"url": base_url+'quicklinks/viewnews',
					"type": "POST"
				},
				"columnDefs": [{ orderable: false, targets: [0] }],
				"order": [[6, "desc" ]]
			});
			
			$('#news').on( 'draw.dt', function () {
				$('[data-plugin="switchery"]').each(function (idx, obj) {
					new Switchery($(this)[0], $(this).data());
				});
			});
			
			$('body').on('click','.del',function() {
				if(confirm('Are you sure?')){
					var elm = $(this);
					var id = elm.attr('ref');
					$.ajax({
						url: base_url+'quicklinks/delete',
						type: 'POST',
						data: {'id':id},
						success: function(res){
							oTable.row(elm.parents('tr')).remove().draw();
						},
						error: function () {
							alert('Something went wrong!');
						}
					});
				}
			});
		}
		
		if($("#newsdate-new").length != 0) {
			
			
			var oTable = $("#newsdate-new").DataTable({
				"processing": true,
				"serverSide": true,
				"ajax": {
					"url": base_url+'news/viewnewsdate',
					"type": "POST"
				},
				"columnDefs": [{ orderable: false, targets: [0,1,2] }]
			});
			
			
			$('body').on('submit', '#news_form',function(event){
				var date = $('#news_date').val();
				//console.log('Preenu Test..' + date);				
				//alert('My click');
				event.preventDefault();
				if(date != ''){
					$.ajax({
						url: base_url+'news/addnewsdate',
						type: 'POST',
						data: new FormData(this),
						contentType:false,
						processData:false,
						success: function(res){
							//oTable.row(elm.parents('tr')).remove().draw();	
							if(res.indexOf('Already Exist') >= 0){
								alert('Given Date already Exist');
							}else{
								
								$('#news_form')[0].reset();
								$('#newsModal').modal('hide');
								oTable.ajax.reload();
							}
							
						},
						error: function () {
							alert('Something went wrong!');
						}
					});
				}
			});
            
            
            
            $('body').on('click','.del',function() {
				if(confirm('Are you sure?')){
					var elm = $(this);
					var id = elm.attr('ref');
					$.ajax({
						url: base_url+'news/delete',
						type: 'POST',
						data: {'id':id},
						success: function(res){
							oTable.row(elm.parents('tr')).remove().draw();
						},
						error: function () {
							alert('Something went wrong!');
						}
					});
				}
			});
		}
		
		if($('#newsdetails-new').length != 0) {
			
			var news_id = $('#news_id').val();
						
			var oTable = $("#newsdetails-new").DataTable({
				"processing": true,
				"serverSide": true,
				"ajax": {
					"url": base_url+'newsdetails/viewnewsdetails/'+news_id,
					"type": "POST"
				},
				"columnDefs": [{ orderable: false, targets: [0,1,2] }]
			});
			
			
			$('body').on('submit', '#news_details_form',function(event){
				var news_header = $('#news_header').val();
				var news_id = $('#news_id').val();
				var news_href = $('#news_href').val();
				console.log('News Details..' + news_header + "-" + news_id + " -"+ news_href);				
				//alert('My click');
				event.preventDefault();
				if(news_id != ''){
					$.ajax({
						url: base_url+'newsdetails/addnewsdetails',
						type: 'POST',
						data: new FormData(this),
						contentType:false,
						processData:false,
						success: function(res){
							//oTable.row(elm.parents('tr')).remove().draw();	
													
							    //alert(res);
								$('#news_details_form')[0].reset();
								$('#newsdetailsModal').modal('hide');
								oTable.ajax.reload();
							
							
						},
						error: function () {
							alert('Something went wrong!');
						}
					});
				} 
			});
            
            
            $('body').on('click','.del',function() {
				if(confirm('Are you sure?')){
					var elm = $(this);
					var id = elm.attr('ref');
					$.ajax({
						url: base_url+'newsdetails/delete',
						type: 'POST',
						data: {'id':id},
						success: function(res){
							oTable.row(elm.parents('tr')).remove().draw();
						},
						error: function () {
							alert('Something went wrong!');
						}
					});
				}
			});
		}
		
		
        
        
        
	}
	
    function init() {
        initSlimscroll();
        initMetisMenu();
        initLeftMenuCollapse();
        initComponents();
        initDependencies();
        handleUserTable();
    }
    init();

})(jQuery)
